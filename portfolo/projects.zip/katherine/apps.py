from django.apps import AppConfig


class KatherineConfig(AppConfig):
    name = 'katherine'
