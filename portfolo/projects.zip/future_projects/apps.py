from django.apps import AppConfig


class FutureProjectsConfig(AppConfig):
    name = 'future_projects'
